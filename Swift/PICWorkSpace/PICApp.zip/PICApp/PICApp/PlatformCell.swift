//
//  PlatformCell.swift
//  PICApp
//
//  Created by 360-jr on 2024/4/22.
//

import Foundation
import UIKit
class PlatformCell: UITableViewCell{
    
}
