//
//  PIC.h
//  PIC
//
//  Created by m1 on 2024/3/28.
//

#import <Foundation/Foundation.h>

//! Project version number for PIC.
FOUNDATION_EXPORT double PICVersionNumber;

//! Project version string for PIC.
FOUNDATION_EXPORT const unsigned char PICVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PIC/PublicHeader.h>


